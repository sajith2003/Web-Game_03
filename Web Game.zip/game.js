/* =========================================================
   COIN RUN — game.js
   A three-stage arcade game built with plain Canvas 2D.
   Stage 1: Endless lane runner  -> collect coins
   Stage 2: Gun shop + practice  -> spend coins, equip a gun
   Stage 3: Missions             -> use the gun on real objectives
   ========================================================= */

/* ---------------------------------------------------------
   1. GLOBAL STATE
   --------------------------------------------------------- */
const GAME = {
  coins: 0,
  lives: 3,
  maxLives: 3,
  ownedGuns: [],        // array of gun ids the player has bought
  equippedGun: null,    // id of the gun currently equipped
  missionsCleared: new Set(),
  hasCompletedGame: false,
};

const GUNS = [
  { id:'pistol', name:'Pistol',  price:30,  power:'Damage ★☆☆', fire:'Fire rate: fast'   },
  { id:'shotgun',name:'Shotgun', price:60,  power:'Damage ★★☆', fire:'Fire rate: medium' },
  { id:'rifle',  name:'Rifle',   price:100, power:'Damage ★★☆', fire:'Fire rate: fast'   },
  { id:'sniper', name:'Sniper',  price:150, power:'Damage ★★★', fire:'Fire rate: slow'   },
];

const MISSIONS = [
  { id:'m1', name:'Perimeter Watch', type:'timedHits',
    desc:'Hit 15 targets before the clock runs out (40s).',
    targetHits:15, timeLimit:40 },
  { id:'m2', name:'Bullseye Run', type:'limitedAmmo',
    desc:'Hit 10 targets — you only get 15 shots.',
    targetHits:10, ammo:15 },
  { id:'m3', name:'Wave Defense', type:'waveDefense',
    desc:'Survive 3 waves. Don\u2019t let more than 5 targets slip past.',
    waves:3, maxEscapes:5 },
];

/* ---------------------------------------------------------
   2. DOM SHORTCUTS + SCREEN SWITCHING
   --------------------------------------------------------- */
const $ = (sel) => document.querySelector(sel);
const screens = document.querySelectorAll('.screen');
const hud = $('#hud');

// Tracks whichever requestAnimationFrame loop is currently running,
// so we can cancel it cleanly whenever the player leaves a screen.
let activeLoop = null;

function stopActiveLoop(){
  if (activeLoop) { cancelAnimationFrame(activeLoop); activeLoop = null; }
}

function showScreen(id, opts = {}){
  stopActiveLoop();
  screens.forEach(s => s.classList.remove('active'));
  $(id).classList.add('active');
  hud.classList.toggle('hidden', !opts.hud);
  if (opts.levelTag) $('#hud-level-tag').textContent = opts.levelTag;
  renderHUD();
}

function showOverlay(id){ $(id).classList.remove('hidden'); }
function hideOverlay(id){ $(id).classList.add('hidden'); }

/* ---------------------------------------------------------
   3. HUD RENDERING (hearts + coins) — the sketch's signature bit
   --------------------------------------------------------- */
function heartSVG(full){
  return `<svg viewBox="0 0 32 29" class="heart ${full ? 'full':'lost'}">
    <path d="M16 28 C 2 18, -4 8, 6 2 C 12 -1, 16 4, 16 8
             C 16 4, 20 -1, 26 2 C 36 8, 30 18, 16 28 Z"/>
  </svg>`;
}

function renderHUD(){
  $('#hud-coin-count').textContent = GAME.coins;
  const heartsHTML = Array.from({length: GAME.maxLives}, (_, i) =>
    `<div class="heart-slot">${heartSVG(i < GAME.lives)}</div>`
  ).join('');
  $('#hud-hearts').innerHTML = heartsHTML;
}

/* ---------------------------------------------------------
   4. START SCREEN
   --------------------------------------------------------- */
$('#btn-start').addEventListener('click', () => startLevel1());

/* =========================================================
   LEVEL 1 — LANE RUNNER
   ========================================================= */
const runnerCanvas = $('#canvas-runner');
const rctx = runnerCanvas.getContext('2d');
const RUNNER_W = runnerCanvas.width, RUNNER_H = runnerCanvas.height;
const LANES = [RUNNER_W*0.22, RUNNER_W*0.5, RUNNER_W*0.78];
const GROUND_Y = RUNNER_H - 70;

let runner; // mutable state for the current run

function startLevel1(){
  GAME.coins = 0;
  GAME.lives = GAME.maxLives;
  runner = {
    lane: 1,               // 0,1,2 (left, center, right)
    displayX: LANES[1],
    jumpV: 0,
    jumpY: 0,               // 0 = ground, negative = in the air
    isJumping:false,
    invincibleUntil:0,
    obstacles: [],          // {type:'lane'|'barrier', lane, y}  — approach from the top
    coins: [],              // {lane, y}
    spawnTimer:0,
    speed:5,
    frame:0,
    groundScroll:0,
    goalShown:false,
    ended:false,
  };
  addFloatingShopButton();
  showScreen('#screen-level1', { hud:true, levelTag:'LEVEL 01 · RUN' });
  hideOverlay('#overlay-goal');
  hideOverlay('#overlay-gameover');
  activeLoop = requestAnimationFrame(runnerLoop);
}

// Small floating button that appears once 100+ coins are banked,
// letting the player jump to the shop at any moment (per the "otherwise
// player collects how much they want" note).
let floatBtn;
function addFloatingShopButton(){
  if (floatBtn) floatBtn.remove();
  floatBtn = document.createElement('button');
  floatBtn.className = 'btn btn-primary';
  floatBtn.textContent = '→ Gun Shop';
  floatBtn.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:80;display:none;';
  floatBtn.addEventListener('click', () => goToShop());
  document.body.appendChild(floatBtn);
}

function goToShop(){
  if (floatBtn) floatBtn.style.display = 'none';
  hideOverlay('#overlay-goal');
  buildShop();
  showScreen('#screen-shop', { hud:true, levelTag:'LEVEL 02 · SHOP' });
}

// --- input ---
const keys = {};
window.addEventListener('keydown', (e) => {
  keys[e.key] = true;
  if (runner && !runner.ended && $('#screen-level1').classList.contains('active')){
    if (e.key === 'ArrowLeft' || e.key === 'a') moveLane(-1);
    if (e.key === 'ArrowRight' || e.key === 'd') moveLane(1);
    if ((e.key === ' ' || e.key === 'ArrowUp') && !runner.isJumping) jump();
  }
});
window.addEventListener('keyup', (e) => keys[e.key] = false);

// touch: tap left/right half of canvas to switch lane, tap top to jump
runnerCanvas.addEventListener('pointerdown', (e) => {
  if (!runner || runner.ended) return;
  const rect = runnerCanvas.getBoundingClientRect();
  const relY = (e.clientY - rect.top) / rect.height;
  const relX = (e.clientX - rect.left) / rect.width;
  if (relY < 0.35){ if (!runner.isJumping) jump(); return; }
  if (relX < 0.5) moveLane(-1); else moveLane(1);
});

function moveLane(dir){
  runner.lane = Math.min(2, Math.max(0, runner.lane + dir));
}
function jump(){
  runner.isJumping = true;
  runner.jumpV = -13;
}

function runnerLoop(){
  rctx.clearRect(0,0,RUNNER_W,RUNNER_H);
  runner.frame++;
  runner.groundScroll = (runner.groundScroll + runner.speed) % 40;

  // sky + ground (ground stripes scroll for a sense of forward motion)
  rctx.fillStyle = '#0a0d12';
  rctx.fillRect(0,0,RUNNER_W,RUNNER_H);
  rctx.fillStyle = '#151b24';
  rctx.fillRect(0, GROUND_Y, RUNNER_W, RUNNER_H - GROUND_Y);
  rctx.strokeStyle = '#2a3140';
  rctx.lineWidth = 2;
  for (let y = -40 + (runner.groundScroll*4 % 60); y < RUNNER_H - GROUND_Y; y += 60){
    rctx.beginPath(); rctx.moveTo(0, GROUND_Y + y); rctx.lineTo(RUNNER_W, GROUND_Y + y); rctx.stroke();
  }
  // lane guides — three lanes the player runs between
  rctx.strokeStyle = 'rgba(255,255,255,0.05)';
  LANES.forEach(lx => { rctx.beginPath(); rctx.moveTo(lx, GROUND_Y); rctx.lineTo(lx, 0); rctx.stroke(); });

  // player physics: glide sideways toward the target lane, jump arcs upward then falls
  const targetX = LANES[runner.lane];
  runner.displayX += (targetX - runner.displayX) * 0.25;
  if (runner.isJumping){
    runner.jumpV += 0.7; // gravity
    runner.jumpY += runner.jumpV;
    if (runner.jumpY >= 0){ runner.jumpY = 0; runner.isJumping = false; runner.jumpV = 0; }
  }

  const PLAYER_Y = GROUND_Y - 34;
  const playerDrawY = PLAYER_Y + runner.jumpY;
  const flashing = performance.now() < runner.invincibleUntil;

  // spawn obstacles & coins — everything approaches from the top of the screen (y grows)
  runner.spawnTimer--;
  if (runner.spawnTimer <= 0){
    runner.spawnTimer = Math.max(34, 60 - Math.floor(runner.frame/300));
    const roll = Math.random();
    if (roll < 0.28){
      runner.obstacles.push({ type:'barrier', y: -30 });
    } else if (roll < 0.62){
      runner.obstacles.push({ type:'lane', lane: Math.floor(Math.random()*3), y: -30 });
    } else {
      runner.coins.push({ lane: Math.floor(Math.random()*3), y: -30 });
    }
  }
  if (Math.random() < 0.05){
    runner.coins.push({ lane: Math.floor(Math.random()*3), y: -30 });
  }

  // move + draw obstacles
  runner.obstacles.forEach(o => o.y += runner.speed);
  runner.obstacles = runner.obstacles.filter(o => o.y < RUNNER_H + 40);
  runner.obstacles.forEach(o => {
    if (o.type === 'barrier'){
      rctx.fillStyle = '#ef476f';
      rctx.fillRect(24, o.y, RUNNER_W - 48, 14);
    } else {
      rctx.fillStyle = '#5a6272';
      rctx.beginPath();
      rctx.arc(LANES[o.lane], o.y, 17, 0, Math.PI*2);
      rctx.fill();
    }
  });

  // move + draw coins
  runner.coins.forEach(c => c.y += runner.speed);
  runner.coins = runner.coins.filter(c => c.y < RUNNER_H + 30);
  runner.coins.forEach(c => {
    rctx.fillStyle = '#ffb703';
    rctx.beginPath();
    rctx.arc(LANES[c.lane], c.y, 10, 0, Math.PI*2);
    rctx.fill();
    rctx.strokeStyle = '#8a690b';
    rctx.stroke();
  });

  // player sprite
  rctx.fillStyle = flashing ? '#ef476f' : '#06d6a0';
  rctx.beginPath();
  if (rctx.roundRect) rctx.roundRect(runner.displayX - 16, playerDrawY, 32, 34, 8);
  else rctx.rect(runner.displayX - 16, playerDrawY, 32, 34);
  rctx.fill();

  // collisions — check objects as they pass through the player's row
  if (!flashing){
    runner.obstacles.forEach(o => {
      const inZone = Math.abs(o.y - PLAYER_Y) < 20;
      if (!inZone) return;
      if (o.type === 'barrier' && !runner.isJumping){
        loseLife(); o.y = RUNNER_H + 999;
      } else if (o.type === 'lane' && o.lane === runner.lane){
        loseLife(); o.y = RUNNER_H + 999;
      }
    });
  }
  // coin pickup
  runner.coins = runner.coins.filter(c => {
    const hit = Math.abs(c.y - PLAYER_Y) < 22 && c.lane === runner.lane;
    if (hit){ GAME.coins++; renderHUD(); checkGoal(); }
    return !hit;
  });

  runner.speed = Math.min(11, 5 + runner.frame/1200);

  if (!runner.ended) activeLoop = requestAnimationFrame(runnerLoop);
}

function loseLife(){
  GAME.lives--;
  renderHUD();
  runner.invincibleUntil = performance.now() + 1200;
  if (GAME.lives <= 0){
    runner.ended = true;
    $('#gameover-coins').textContent = GAME.coins;
    showOverlay('#overlay-gameover');
  }
}

function checkGoal(){
  if (GAME.coins >= 100 && !runner.goalShown){
    runner.goalShown = true;
    showOverlay('#overlay-goal');
  } else if (GAME.coins >= 100 && floatBtn){
    floatBtn.style.display = 'block';
  }
}

$('#btn-keep-running').addEventListener('click', () => {
  hideOverlay('#overlay-goal');
  if (floatBtn) floatBtn.style.display = 'block';
});
$('#btn-goto-shop').addEventListener('click', () => goToShop());
$('#btn-retry').addEventListener('click', () => startLevel1());

/* =========================================================
   LEVEL 2a — GUN SHOP
   ========================================================= */
function buildShop(){
  const grid = $('#gun-grid');
  grid.innerHTML = '';
  GUNS.forEach(gun => {
    const owned = GAME.ownedGuns.includes(gun.id);
    const equipped = GAME.equippedGun === gun.id;
    const card = document.createElement('div');
    card.className = 'gun-card' + (equipped ? ' equipped' : '');
    card.innerHTML = `
      <div class="gun-name">${gun.name}</div>
      <div class="gun-stats">${gun.power}<br>${gun.fire}</div>
      <div class="gun-price">${owned ? 'Owned' : '● ' + gun.price}</div>
      <button class="btn gun-btn ${equipped ? 'btn-primary' : 'btn-ghost'}">
        ${equipped ? 'Equipped ✓' : (owned ? 'Equip' : 'Buy')}
      </button>`;
    const btn = card.querySelector('button');
    btn.disabled = !owned && GAME.coins < gun.price;
    btn.addEventListener('click', () => {
      if (!owned){
        GAME.coins -= gun.price;
        GAME.ownedGuns.push(gun.id);
      }
      GAME.equippedGun = gun.id;
      renderHUD();
      buildShop();
      $('#btn-to-practice').disabled = false;
    });
    grid.appendChild(card);
  });
  $('#btn-to-practice').disabled = !GAME.equippedGun;
}

$('#btn-to-practice').addEventListener('click', () => {
  showScreen('#screen-practice', { hud:true, levelTag:'LEVEL 02 · RANGE' });
  startPractice('standard');
});

/* =========================================================
   LEVEL 2b — PRACTICE RANGE
   ========================================================= */
const practiceCanvas = $('#canvas-practice');
const pctx = practiceCanvas.getContext('2d');
const PW = practiceCanvas.width, PH = practiceCanvas.height;
let practice;

const RANGE_MODES = {
  standard: { spawnEvery:45, life:110, radius:26, label:'Standard' },
  focused:  { spawnEvery:75, life:70,  radius:17, label:'Focused'  },
};

function startPractice(mode){
  practice = { mode, targets:[], hits:0, timeLeft:30, frame:0, spawnTimer:0, running:true };
  $('#practice-hits').textContent = '0';
  $('#practice-timer').textContent = '30';
  document.querySelectorAll('.btn-mode').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));
  hideOverlay('#overlay-practice-done');
  activeLoop = requestAnimationFrame(practiceLoop);
  practice.timerHandle = setInterval(() => {
    if (!practice.running) return;
    practice.timeLeft--;
    $('#practice-timer').textContent = practice.timeLeft;
    if (practice.timeLeft <= 0) endPractice();
  }, 1000);
}

function endPractice(){
  practice.running = false;
  clearInterval(practice.timerHandle);
  $('#practice-result-hits').textContent = practice.hits;
  showOverlay('#overlay-practice-done');
}

function practiceLoop(){
  if (!practice.running) return;
  pctx.clearRect(0,0,PW,PH);
  pctx.fillStyle = '#0a0d12';
  pctx.fillRect(0,0,PW,PH);
  // simple range backdrop
  pctx.strokeStyle = '#2a3140';
  for (let x=0; x<PW; x+=60){ pctx.beginPath(); pctx.moveTo(x,0); pctx.lineTo(x,PH); pctx.stroke(); }

  const cfg = RANGE_MODES[practice.mode];
  practice.spawnTimer--;
  if (practice.spawnTimer <= 0){
    practice.spawnTimer = cfg.spawnEvery;
    practice.targets.push({
      x: 60 + Math.random()*(PW-120),
      y: 60 + Math.random()*(PH-120),
      r: cfg.radius,
      life: cfg.life,
    });
  }

  practice.targets.forEach(t => t.life--);
  practice.targets = practice.targets.filter(t => t.life > 0);
  practice.targets.forEach(t => {
    pctx.beginPath();
    pctx.fillStyle = '#ef476f';
    pctx.arc(t.x, t.y, t.r, 0, Math.PI*2);
    pctx.fill();
    pctx.fillStyle = '#ffb703';
    pctx.beginPath(); pctx.arc(t.x, t.y, t.r*0.5, 0, Math.PI*2); pctx.fill();
  });

  activeLoop = requestAnimationFrame(practiceLoop);
}

practiceCanvas.addEventListener('pointerdown', (e) => {
  if (!practice || !practice.running) return;
  const rect = practiceCanvas.getBoundingClientRect();
  const x = (e.clientX - rect.left) * (PW / rect.width);
  const y = (e.clientY - rect.top) * (PH / rect.height);
  let hitIndex = -1;
  practice.targets.forEach((t,i) => {
    if (hitIndex !== -1) return;
    const d = Math.hypot(t.x-x, t.y-y);
    if (d <= t.r) hitIndex = i;
  });
  if (hitIndex !== -1){
    practice.targets.splice(hitIndex,1);
    practice.hits++;
    $('#practice-hits').textContent = practice.hits;
  }
});

document.querySelectorAll('.btn-mode').forEach(btn => {
  btn.addEventListener('click', () => {
    clearInterval(practice && practice.timerHandle);
    startPractice(btn.dataset.mode);
  });
});

$('#btn-practice-again').addEventListener('click', () => startPractice(practice.mode));
$('#btn-confirm-ready').addEventListener('click', () => {
  hideOverlay('#overlay-practice-done');
  buildMissions();
  showScreen('#screen-missions', { hud:true, levelTag:'LEVEL 03 · MISSIONS' });
});

/* =========================================================
   LEVEL 3 — MISSIONS
   ========================================================= */
function buildMissions(){
  const list = $('#mission-list');
  list.innerHTML = '';
  MISSIONS.forEach(m => {
    const cleared = GAME.missionsCleared.has(m.id);
    const card = document.createElement('div');
    card.className = 'mission-card' + (cleared ? ' cleared' : '');
    card.innerHTML = `
      <div>
        <div class="mission-name">${m.name} ${cleared ? '<span class="mission-badge">CLEARED ✓</span>' : ''}</div>
        <div class="mission-desc">${m.desc}</div>
      </div>
      <button class="btn btn-primary">Play</button>`;
    card.querySelector('button').addEventListener('click', () => startMission(m));
    list.appendChild(card);
  });
}

const missionCanvas = $('#canvas-mission');
const mctx = missionCanvas.getContext('2d');
const MW = missionCanvas.width, MH = missionCanvas.height;
let mission; // current mission run state

function startMission(m){
  $('#mission-brief-title').textContent = m.name;
  $('#mission-caption').textContent = 'MISSION — ' + m.name.toUpperCase();
  showScreen('#screen-mission-play', { hud:true, levelTag:'LEVEL 03 · MISSION' });

  mission = {
    def: m,
    hits:0,
    time: m.timeLimit || 0,
    ammo: m.ammo || 0,
    wave: 1,
    escapes:0,
    targets:[],
    spawnTimer:0,
    running:true,
  };
  updateMissionStats();
  hideOverlay('#overlay-mission-fail');

  if (m.type === 'timedHits' || m.type === 'limitedAmmo'){
    mission.timerHandle = (m.type === 'timedHits') ? setInterval(() => {
      if (!mission.running) return;
      mission.time--;
      updateMissionStats();
      if (mission.time <= 0) failMission('Time ran out before you hit the target count.');
    }, 1000) : null;
  }

  activeLoop = requestAnimationFrame(missionLoop);
}

function updateMissionStats(){
  const m = mission.def;
  if (m.type === 'timedHits'){
    $('#mission-stat-1').textContent = `Hits: ${mission.hits}/${m.targetHits}`;
    $('#mission-stat-2').textContent = `Time: ${mission.time}s`;
  } else if (m.type === 'limitedAmmo'){
    $('#mission-stat-1').textContent = `Hits: ${mission.hits}/${m.targetHits}`;
    $('#mission-stat-2').textContent = `Ammo: ${mission.ammo}`;
  } else if (m.type === 'waveDefense'){
    $('#mission-stat-1').textContent = `Wave: ${mission.wave}/${m.waves}`;
    $('#mission-stat-2').textContent = `Escapes: ${mission.escapes}/${m.maxEscapes}`;
  }
}

function missionLoop(){
  if (!mission.running) return;
  mctx.clearRect(0,0,MW,MH);
  mctx.fillStyle = '#0a0d12';
  mctx.fillRect(0,0,MW,MH);
  const m = mission.def;

  if (m.type === 'waveDefense'){
    // base line near the bottom — targets that cross it "escape"
    const baseY = MH - 30;
    mctx.strokeStyle = '#ef476f';
    mctx.setLineDash([6,6]);
    mctx.beginPath(); mctx.moveTo(0, baseY); mctx.lineTo(MW, baseY); mctx.stroke();
    mctx.setLineDash([]);

    mission.spawnTimer--;
    if (mission.spawnTimer <= 0 && mission.targets.length < 5 + mission.wave){
      mission.spawnTimer = 50;
      mission.targets.push({ x: 40 + Math.random()*(MW-80), y: -20, r:20, vy: 1 + mission.wave*0.3 });
    }
    mission.targets.forEach(t => t.y += t.vy);
    const escaped = mission.targets.filter(t => t.y > baseY);
    mission.escapes += escaped.length;
    mission.targets = mission.targets.filter(t => t.y <= baseY);

    mission.targets.forEach(t => {
      mctx.fillStyle = '#ef476f';
      mctx.beginPath(); mctx.arc(t.x, t.y, t.r, 0, Math.PI*2); mctx.fill();
    });

    updateMissionStats();
    if (mission.escapes > m.maxEscapes){
      failMission('Too many targets slipped past the line.');
      return;
    }
    // wave cleared when a batch worth of targets has been dealt with
    if (mission.hits + mission.escapes >= (mission.wave * (5 + mission.wave)) && mission.targets.length === 0){
      if (mission.wave >= m.waves){ winMission(); return; }
      mission.wave++;
    }
  } else {
    // timedHits & limitedAmmo share a simple static-target range
    mission.spawnTimer--;
    if (mission.spawnTimer <= 0){
      mission.spawnTimer = 40;
      mission.targets.push({
        x: 60 + Math.random()*(MW-120), y: 60 + Math.random()*(MH-120), r: 24, life: 90,
      });
    }
    mission.targets.forEach(t => t.life--);
    mission.targets = mission.targets.filter(t => t.life > 0);
    mission.targets.forEach(t => {
      mctx.fillStyle = '#06d6a0';
      mctx.beginPath(); mctx.arc(t.x, t.y, t.r, 0, Math.PI*2); mctx.fill();
      mctx.fillStyle = '#0a0d12';
      mctx.beginPath(); mctx.arc(t.x, t.y, t.r*0.4, 0, Math.PI*2); mctx.fill();
    });

    if (mission.hits >= m.targetHits){ winMission(); return; }
    if (m.type === 'limitedAmmo' && mission.ammo <= 0 && mission.hits < m.targetHits){
      failMission('You ran out of ammo before hitting the target count.');
      return;
    }
  }

  activeLoop = requestAnimationFrame(missionLoop);
}

missionCanvas.addEventListener('pointerdown', (e) => {
  if (!mission || !mission.running) return;
  const m = mission.def;
  const rect = missionCanvas.getBoundingClientRect();
  const x = (e.clientX - rect.left) * (MW / rect.width);
  const y = (e.clientY - rect.top) * (MH / rect.height);

  if (m.type === 'limitedAmmo'){
    if (mission.ammo <= 0) return;
    mission.ammo--;
  }
  let hitIndex = -1;
  mission.targets.forEach((t,i) => {
    if (hitIndex !== -1) return;
    if (Math.hypot(t.x-x, t.y-y) <= t.r) hitIndex = i;
  });
  if (hitIndex !== -1){
    mission.targets.splice(hitIndex,1);
    mission.hits++;
  }
  updateMissionStats();
});

function failMission(reason){
  mission.running = false;
  clearInterval(mission.timerHandle);
  $('#mission-fail-copy').textContent = reason;
  showOverlay('#overlay-mission-fail');
}

function winMission(){
  mission.running = false;
  clearInterval(mission.timerHandle);
  GAME.missionsCleared.add(mission.def.id);
  $('#victory-mission-name').textContent = mission.def.name;
  $('#overlay-victory h2').textContent = GAME.hasCompletedGame ? '🎯 Mission Cleared' : '🏆 Mission Cleared';
  $('#overlay-victory .eyebrow').textContent = GAME.hasCompletedGame ? 'MISSION CLEARED' : 'GAME COMPLETED';
  GAME.hasCompletedGame = true;
  showOverlay('#overlay-victory');
}

$('#btn-mission-back').addEventListener('click', () => {
  hideOverlay('#overlay-mission-fail');
  buildMissions();
  showScreen('#screen-missions', { hud:true, levelTag:'LEVEL 03 · MISSIONS' });
});
$('#btn-mission-retry').addEventListener('click', () => {
  hideOverlay('#overlay-mission-fail');
  startMission(mission.def);
});
$('#btn-continue-missions').addEventListener('click', () => {
  hideOverlay('#overlay-victory');
  buildMissions();
  showScreen('#screen-missions', { hud:true, levelTag:'LEVEL 03 · MISSIONS' });
});
$('#btn-restart-game').addEventListener('click', () => {
  hideOverlay('#overlay-victory');
  GAME.coins = 0; GAME.ownedGuns = []; GAME.equippedGun = null;
  GAME.missionsCleared.clear(); GAME.hasCompletedGame = false;
  showScreen('#screen-start');
});

/* initial render */
renderHUD();
